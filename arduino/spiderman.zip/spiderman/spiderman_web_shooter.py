"""
Spiderman Web Shooter Gesture Detector
---------------------------------------
Gesture: jempol + telunjuk + kelingking DIRENTANGKAN,
         jari tengah + manis DITEKUK (kayak gesture web-shooter Spiderman).

Kalau gesture kedetect -> muncul animasi jaring laba-laba nembak dari
posisi ujung telunjuk, terus menghilang pelan-pelan (fade out).

CATATAN: mediapipe versi baru (1.x) udah BUANG API lama `mp.solutions.hands`.
Script ini pake API baru: MediaPipe Tasks (HandLandmarker), jadi tetap jalan
di mediapipe versi terbaru. Model .task bakal didownload otomatis sekali
pas pertama kali run (butuh internet), abis itu disimpen lokal.

Butuh: opencv-python, mediapipe
Install: pip install opencv-python mediapipe
"""

import cv2
import numpy as np
import mediapipe as mp
import math
import time
import os
import urllib.request

from mediapipe.tasks import python as mp_tasks
from mediapipe.tasks.python import vision as mp_vision

MODEL_URL = (
    "https://storage.googleapis.com/mediapipe-models/hand_landmarker/"
    "hand_landmarker/float16/latest/hand_landmarker.task"
)
MODEL_PATH = "hand_landmarker.task"

HAND_CONNECTIONS = [
    (0, 1), (1, 2), (2, 3), (3, 4),          
    (0, 5), (5, 6), (6, 7), (7, 8),          
    (5, 9), (9, 10), (10, 11), (11, 12),     
    (9, 13), (13, 14), (14, 15), (15, 16),   
    (13, 17), (17, 18), (18, 19), (19, 20),  
    (0, 17),
]


def download_model_if_needed():
    if not os.path.exists(MODEL_PATH):
        print("Download model hand_landmarker.task (sekali doang)...")
        urllib.request.urlretrieve(MODEL_URL, MODEL_PATH)
        print("Selesai download model.")


def draw_hand(frame, landmarks, w, h):
    pts = [(int(lm.x * w), int(lm.y * h)) for lm in landmarks]
    for a, b in HAND_CONNECTIONS:
        cv2.line(frame, pts[a], pts[b], (0, 255, 0), 2)
    for p in pts:
        cv2.circle(frame, p, 4, (0, 0, 255), -1)



def dist(a, b):
    return math.hypot(a.x - b.x, a.y - b.y)


def is_finger_extended(landmarks, tip_id, pip_id, wrist):
    return dist(wrist, landmarks[tip_id]) > dist(wrist, landmarks[pip_id]) * 1.15


def is_web_shooter_gesture(landmarks):
    wrist = landmarks[0]

    thumb_ext  = is_finger_extended(landmarks, 4, 2, wrist)
    index_ext  = is_finger_extended(landmarks, 8, 6, wrist)
    middle_ext = is_finger_extended(landmarks, 12, 10, wrist)
    ring_ext   = is_finger_extended(landmarks, 16, 14, wrist)
    pinky_ext  = is_finger_extended(landmarks, 20, 18, wrist)

    return thumb_ext and index_ext and pinky_ext and (not middle_ext) and (not ring_ext)



class WebEffect:
    """Satu instance efek jaring yang muncul terus fade out sendiri."""

    LIFETIME = 0.8  

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.start = time.time()

    def alive(self):
        return (time.time() - self.start) < self.LIFETIME

    def progress(self):
        return min((time.time() - self.start) / self.LIFETIME, 1.0)

    def draw(self, frame):
        p = self.progress()
        radius = int(20 + p * 120)          # jaring makin membesar
        alpha = max(0.0, 1.0 - p)           # makin transparan

        overlay = frame.copy()
        color = (255, 255, 255)
        outline = (0, 0, 0)  

        n_spokes = 10
        n_rings = 4

        spoke_pts = []
        for i in range(n_spokes):
            angle = (2 * math.pi / n_spokes) * i - math.pi / 2
            x2 = int(self.x + radius * math.cos(angle))
            y2 = int(self.y + radius * math.sin(angle))
            spoke_pts.append((x2, y2))

        def draw_layered_line(p1, p2):
            cv2.line(overlay, p1, p2, outline, 5, cv2.LINE_AA)
            cv2.line(overlay, p1, p2, color, 2, cv2.LINE_AA)

        def draw_layered_poly(pts):
            pts_arr = np.array(pts, dtype=np.int32)
            cv2.polylines(overlay, [pts_arr], False, outline, 5, cv2.LINE_AA)
            cv2.polylines(overlay, [pts_arr], False, color, 2, cv2.LINE_AA)

        for pt in spoke_pts:
            draw_layered_line((self.x, self.y), pt)

        # gambar ring melengkung (bowed outward) antar spoke, di beberapa radius
        for ring in range(1, n_rings + 1):
            r = radius * ring / n_rings
            pts_ring = []
            for i in range(n_spokes):
                angle = (2 * math.pi / n_spokes) * i - math.pi / 2
                x = self.x + r * math.cos(angle)
                y = self.y + r * math.sin(angle)
                pts_ring.append((x, y))

            for i in range(n_spokes):
                p1 = pts_ring[i]
                p2 = pts_ring[(i + 1) % n_spokes]
                mx, my = (p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2
                dx, dy = mx - self.x, my - self.y
                d = math.hypot(dx, dy) or 1
                bow = r * 0.15
                bmx, bmy = mx + (dx / d) * bow, my + (dy / d) * bow
                draw_layered_poly([p1, (bmx, bmy), p2])

        cv2.addWeighted(overlay, alpha, frame, 1 - alpha, 0, frame)

        cv2.addWeighted(overlay, alpha, frame, 1 - alpha, 0, frame)



def main():
    download_model_if_needed()

    base_options = mp_tasks.BaseOptions(model_asset_path=MODEL_PATH)
    options = mp_vision.HandLandmarkerOptions(
        base_options=base_options,
        running_mode=mp_vision.RunningMode.VIDEO,
        num_hands=1,
        min_hand_detection_confidence=0.7,
        min_tracking_confidence=0.6,
    )
    detector = mp_vision.HandLandmarker.create_from_options(options)

    cap = cv2.VideoCapture(0)
    effects = []
    last_spawn = 0
    cooldown = 1.2       
    gesture_was_active = False   
    start_time = time.time()

    while cap.isOpened():
        ok, frame = cap.read()
        if not ok:
            print("Kamera ga kebaca. Cek device-nya.")
            break

        frame = cv2.flip(frame, 1)
        h, w, _ = frame.shape
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)

        timestamp_ms = int((time.time() - start_time) * 1000)
        result = detector.detect_for_video(mp_image, timestamp_ms)

        if result.hand_landmarks:
            for landmarks in result.hand_landmarks:
                draw_hand(frame, landmarks, w, h)

                gesture_now = is_web_shooter_gesture(landmarks)

                if gesture_now:
                    index_tip = landmarks[8]
                    x, y = int(index_tip.x * w), int(index_tip.y * h)

                    cv2.putText(
                        frame, "WEB SHOOTER!", (x - 60, y - 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2
                    )

                    now = time.time()
                    just_formed = gesture_now and not gesture_was_active
                    if just_formed and (now - last_spawn > cooldown):
                        effects.append(WebEffect(x, y))
                        last_spawn = now

                gesture_was_active = gesture_now
        else:
            gesture_was_active = False

        effects = [e for e in effects if e.alive()]
        for e in effects:
            e.draw(frame)

        cv2.imshow("Spiderman Web Shooter", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    detector.close()
    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()